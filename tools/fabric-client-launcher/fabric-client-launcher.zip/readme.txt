Configuration instructions:

Default configuration is located in lib/config.properties, it can be overrided by creating lib/config-ext.properties, and it can be further overrided by user supplied properties indicated by "config" jvm system property.

For simple starter usage, just need to configure "portal.fabric.server.host" pointing to portal server.